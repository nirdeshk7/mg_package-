# mg_prod_app.py - MG production-ready app (voice disabled)
import streamlit as st, yaml, os, json
from security import log_event, is_panic, trigger_panic
st.set_page_config(page_title="MG", layout="wide")
BASE = os.path.dirname(__file__)
try:
    with open(os.path.join(BASE,'config.yaml')) as f: cfg = yaml.safe_load(f)
except Exception:
    cfg = {}

st.title(f"{cfg.get('app_name','MG')} — Document & Smart Home Assistant")

if is_panic():
    st.error("MG is in PANIC mode. Contact admin.")
    st.stop()

# Load devices
devices_path = os.path.join(BASE,'devices.json')
try:
    with open(devices_path) as f: devices = json.load(f)
except Exception:
    devices = {"devices": []}

col1, col2 = st.columns([1,2])
with col1:
    st.header("Upload / Ingest Documents")
    uploaded = st.file_uploader("Upload files (xlsx, csv, pdf, docx, txt, images)", accept_multiple_files=True)
    if uploaded:
        for up in uploaded:
            name = up.name; lower = name.lower(); text = ""
            if lower.endswith(('.xlsx','.xls')):
                import pandas as pd
                dfd = pd.read_excel(up, sheet_name=None)
                parts = []
                for s,df in dfd.items():
                    parts.append(f"--- SHEET: {s} ---\n" + df.head(200).to_csv(index=False))
                text = "\n".join(parts)
            elif lower.endswith('.csv'):
                import pandas as pd
                df = pd.read_csv(up)
                text = df.head(1000).to_csv(index=False)
            elif lower.endswith('.pdf'):
                import pdfplumber, tempfile
                tf = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf'); tf.write(up.read()); tf.close()
                with pdfplumber.open(tf.name) as pdf:
                    pages = [p.extract_text() or "" for p in pdf.pages]
                text = "\n".join(pages)
                try: os.unlink(tf.name)
                except: pass
            elif lower.endswith('.docx'):
                import docx, tempfile
                tf = tempfile.NamedTemporaryFile(delete=False, suffix='.docx'); tf.write(up.read()); tf.close()
                doc = docx.Document(tf.name)
                text = "\n".join([p.text for p in doc.paragraphs if p.text])
                try: os.unlink(tf.name)
                except: pass
            elif lower.endswith(('.png','.jpg','.jpeg')):
                from PIL import Image
                import pytesseract
                img = Image.open(up); text = pytesseract.image_to_string(img)
            elif lower.endswith('.txt'):
                text = up.read().decode('utf-8', errors='ignore')
            else:
                st.warning("Unsupported file: " + name); continue
            if 'docs' not in st.session_state: st.session_state['docs'] = []
            st.session_state['docs'].append({'name': name, 'text': text})
            log_event('upload', {'name': name, 'len': len(text)})
        st.success("Files processed. Build index from sidebar.")

    st.markdown("---")
    st.header("Device Onboarding")
    name = st.text_input("Device name")
    dtype = st.selectbox("Device type", ["home_assistant","broadlink","chromecast","mqtt","generic_http"])
    if st.button("Register device"):
        devices.setdefault('devices',[]).append({'id': len(devices.get('devices',[]))+1, 'name': name, 'type': dtype, 'config': {}})
        with open(devices_path,'w') as f: json.dump(devices,f, indent=2)
        st.success("Device registered (placeholder)"); log_event('device_registered', {'name': name, 'type': dtype})

with col2:
    st.header("Index & QA")
    if st.button("Build embeddings index from uploaded docs"):
        if 'docs' not in st.session_state or len(st.session_state['docs'])==0:
            st.warning("Upload files first.")
        else:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer('all-MiniLM-L6-v2')
            all_chunks = []
            for d in st.session_state['docs']:
                words = d['text'].split()
                chunk_size = 400
                i=0
                while i < len(words):
                    all_chunks.append(' '.join(words[i:i+chunk_size]))
                    i += chunk_size - 50
            embs = model.encode(all_chunks, convert_to_numpy=True, show_progress_bar=True)
            st.session_state['index_texts'] = all_chunks
            st.session_state['index_embs'] = embs.tolist()
            st.success(f"Indexed {len(all_chunks)} chunks."); log_event('index_built', {'chunks': len(all_chunks)})

    st.markdown('---')
    st.header("Ask MG")
    q = st.text_input("Ask a question about uploaded docs:")
    topk = st.slider("Top-k", 1, 10, 5)
    if st.button("Ask") and q.strip():
        if 'index_embs' not in st.session_state:
            st.error("Build index first.")
        else:
            import numpy as np
            from sklearn.metrics.pairwise import cosine_similarity
            from sentence_transformers import SentenceTransformer
            qv = SentenceTransformer('all-MiniLM-L6-v2').encode([q], convert_to_numpy=True)[0]
            embs = np.array(st.session_state['index_embs'])
            sims = cosine_similarity([qv], embs)[0]
            idxs = sims.argsort()[::-1][:topk]
            out = "Top passages:\n\n"
            for i in idxs:
                out += f"(score:{sims[i]:.3f}) " + st.session_state['index_texts'][int(i)][:500].replace('\n',' ') + "\n\n"
            st.text_area("MG reply", value=out, height=300)
            log_event('qa', {'q': q, 'topk': topk})

    st.markdown('---')
    st.header("Control Panel & Security")
    try:
        with open(devices_path) as f: devices = json.load(f)
    except Exception:
        devices = {'devices': []}
    for d in devices.get('devices', []):
        st.write(f"{d['id']}: {d['name']} ({d['type']})")
    st.markdown('---')
    if st.button("Trigger panic (lockdown)"):
        trigger_panic(); st.warning("Panic triggered"); log_event('panic_manual', {})
st.caption("MG - production skeleton. Configure adapters and secrets before enabling device control.")
