# mqtt_adapter.py - stub
