# chromecast_adapter.py - stub
