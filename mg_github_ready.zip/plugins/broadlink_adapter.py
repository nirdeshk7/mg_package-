# broadlink_adapter.py - stub
