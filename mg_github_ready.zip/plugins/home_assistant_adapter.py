# home_assistant_adapter.py - stub
