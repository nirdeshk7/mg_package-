# shopping_adapter.py - stub
