# secrets_helper.py - local secrets helper using cryptography.Fernet
import argparse, json, os
from cryptography.fernet import Fernet

def genkey(path="secrets.key"):
    k = Fernet.generate_key()
    with open(path, "wb") as f: f.write(k)
    print("Generated key at", path)

def encrypt(keyfile, data_json, outpath="secrets.enc"):
    with open(keyfile, "rb") as f: key=f.read()
    fernet = Fernet(key)
    token = fernet.encrypt(json.dumps(data_json).encode())
    with open(outpath, "wb") as f: f.write(token)
    print("Encrypted saved to", outpath)

def decrypt(keyfile, inpath="secrets.enc"):
    with open(keyfile, "rb") as f: key=f.read()
    fernet = Fernet(key)
    with open(inpath, "rb") as f: token=f.read()
    print(fernet.decrypt(token).decode())

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('cmd', choices=['genkey','encrypt','decrypt'])
    p.add_argument('--keyfile', default='secrets.key')
    p.add_argument('--data', help='JSON string for encrypt')
    p.add_argument('--infile', default='secrets.enc')
    p.add_argument('--outfile', default='secrets.enc')
    args=p.parse_args()
    if args.cmd=='genkey': genkey(args.keyfile)
    elif args.cmd=='encrypt' and args.data: encrypt(args.keyfile, json.loads(args.data), args.outfile)
    elif args.cmd=='decrypt': decrypt(args.keyfile, args.infile)
