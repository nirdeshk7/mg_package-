# MG — Document & Smart Home Assistant (GitHub-ready)

This repository contains MG, a local-first Document & Smart Home assistant skeleton designed to be extended and safely hosted.
