# security.py - HMAC-audited logs and panic flag
import os, json, time, hmac, hashlib
HMAC_KEY = 'hmac_key.bin'
AUDIT_LOG = 'mg_audit.log'
PANIC_FLAG = 'panic.flag'

def _load_key():
    if not os.path.exists(HMAC_KEY):
        k = os.urandom(32)
        with open(HMAC_KEY,'wb') as f: f.write(k)
        return k
    return open(HMAC_KEY,'rb').read()

def log_event(evt, details):
    k = _load_key()
    entry = {'ts': int(time.time()), 'event': evt, 'details': details}
    raw = json.dumps(entry, sort_keys=True).encode()
    sig = hmac.new(k, raw, hashlib.sha256).hexdigest()
    with open(AUDIT_LOG,'a') as f: f.write(json.dumps({'entry':entry,'hmac':sig}) + '\n')

def trigger_panic():
    open(PANIC_FLAG,'w').close()
    log_event('panic_triggered', {})

def is_panic():
    return os.path.exists(PANIC_FLAG)
